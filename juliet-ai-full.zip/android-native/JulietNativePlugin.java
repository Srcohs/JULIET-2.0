package com.ahsanraza.juliet;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import java.util.ArrayList;
import java.util.Iterator;

@CapacitorPlugin(name = "JulietNative")
public class JulietNativePlugin extends Plugin {

  @PluginMethod
  public void setConfig(PluginCall call) {
    SharedPreferences.Editor e = getContext().getSharedPreferences("juliet", 0).edit();
    JSObject d = call.getData();
    Iterator<String> it = d.keys();
    while (it.hasNext()) {
      String k = it.next();
      e.putString(k, d.optString(k, ""));
    }
    e.apply();
    call.resolve();
  }

  @PluginMethod
  public void requestAll(PluginCall call) {
    final ArrayList<String> p = new ArrayList<>();
    p.add(Manifest.permission.RECORD_AUDIO);
    p.add(Manifest.permission.CALL_PHONE);
    p.add(Manifest.permission.SEND_SMS);
    p.add(Manifest.permission.READ_CONTACTS);
    p.add(Manifest.permission.READ_PHONE_STATE);
    p.add(Manifest.permission.READ_CALL_LOG);
    if (Build.VERSION.SDK_INT >= 26) p.add(Manifest.permission.ANSWER_PHONE_CALLS);
    if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS);
    getActivity().runOnUiThread(new Runnable() {
      @Override
      public void run() {
        ActivityCompat.requestPermissions(getActivity(), p.toArray(new String[0]), 7001);
      }
    });
    call.resolve();
  }

  @PluginMethod
  public void status(PluginCall call) {
    Context c = getContext();
    JSObject r = new JSObject();
    r.put("mic", Tools.has(c, Manifest.permission.RECORD_AUDIO));
    r.put("call", Tools.has(c, Manifest.permission.CALL_PHONE));
    r.put("sms", Tools.has(c, Manifest.permission.SEND_SMS));
    r.put("contacts", Tools.has(c, Manifest.permission.READ_CONTACTS));
    r.put("phoneState", Tools.has(c, Manifest.permission.READ_PHONE_STATE));
    r.put("notif", NotificationManagerCompat.from(c).areNotificationsEnabled());
    r.put("ax", axOn(c));
    r.put("nl", NotificationManagerCompat.getEnabledListenerPackages(c).contains(c.getPackageName()));
    boolean bat = true;
    try {
      PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
      if (Build.VERSION.SDK_INT >= 23) bat = pm.isIgnoringBatteryOptimizations(c.getPackageName());
    } catch (Exception e) {
      bat = true;
    }
    r.put("battery", bat);
    r.put("running", JulietService.RUNNING);
    call.resolve(r);
  }

  @PluginMethod
  public void startService(PluginCall call) {
    Context c = getContext();
    if (!Tools.has(c, Manifest.permission.RECORD_AUDIO)) {
      call.reject("Pehle permissions allow karo");
      return;
    }
    try {
      ContextCompat.startForegroundService(c, new Intent(c, JulietService.class));
      call.resolve();
    } catch (Exception e) {
      call.reject("Service start nahi hui: " + e.getMessage());
    }
  }

  @PluginMethod
  public void stopService(PluginCall call) {
    Context c = getContext();
    c.stopService(new Intent(c, JulietService.class));
    call.resolve();
  }

  @PluginMethod
  public void call(PluginCall pc) {
    String n = pc.getString("number");
    if (Tools.call(getContext(), n)) pc.resolve();
    else pc.reject("Call nahi lag saka");
  }

  @PluginMethod
  public void sendSms(PluginCall pc) {
    String n = pc.getString("number");
    String t = pc.getString("text");
    if (Tools.sms(getContext(), n, t)) pc.resolve();
    else pc.reject("SMS nahi ja saka");
  }

  @PluginMethod
  public void findContact(PluginCall pc) {
    String num = Tools.number(getContext(), pc.getString("name"));
    JSObject r = new JSObject();
    r.put("number", num == null ? "" : num);
    pc.resolve(r);
  }

  static boolean axOn(Context c) {
    if (JulietAccessibility.INSTANCE != null) return true;
    try {
      String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
      return s != null && s.contains(c.getPackageName() + "/");
    } catch (Exception e) {
      return false;
    }
  }

  @PluginMethod
  public void doAction(final PluginCall call) {
    final JSObject d = call.getData();
    new Thread(new Runnable() {
      @Override
      public void run() {
        String m = Actions.run(getContext(), d);
        JSObject r = new JSObject();
        r.put("message", m == null ? "" : m);
        call.resolve(r);
      }
    }).start();
  }

  @PluginMethod
  public void openSettings(PluginCall call) {
    String t = call.getString("type", "app");
    Context c = getContext();
    String pkg = c.getPackageName();
    Intent i;
    if (t.equals("accessibility")) i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
    else if (t.equals("notifications_access")) i = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
    else if (t.equals("notifications")) i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
    else if (t.equals("battery")) i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + pkg));
    else i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + pkg));
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    try {
      c.startActivity(i);
      call.resolve();
    } catch (Exception e) {
      try {
        Intent f = new Intent(Settings.ACTION_SETTINGS);
        f.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(f);
        call.resolve();
      } catch (Exception e2) {
        call.reject("Settings nahi khuli");
      }
    }
  }
}
