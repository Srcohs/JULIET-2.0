package com.juliet.ai.wa

import android.app.Notification
import android.os.Bundle
import android.service.notification.StatusBarNotification

/** One notification, parsed once. Chat type comes from the notification's own metadata, never guessed. */
class Incoming(
    val pkg: String,
    val key: String,
    val sender: String,
    val text: String,
    val time: Long,
    val fromOther: Boolean,          // false when the latest message is our own / the user's
    val isGroup: Boolean,
    val verifiedPrivate: Boolean,    // true only when Android says "not a group" explicitly
    val groupTitle: String?,
    val replyAction: Notification.Action?
) {
    val id: String get() = "$key|$time|${text.hashCode()}"

    companion object {
        fun parse(sbn: StatusBarNotification): Incoming? {
            val n = sbn.notification ?: return null
            val x = n.extras ?: return null
            val title = x.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
            val plain = x.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
            @Suppress("DEPRECATION")
            val last = x.getParcelableArray(Notification.EXTRA_MESSAGES)?.lastOrNull() as? Bundle
            val text = last?.getCharSequence("text")?.toString() ?: plain
            val senderName = last?.getCharSequence("sender")?.toString()
            val self = x.getCharSequence("android.selfDisplayName")?.toString()
            val fromOther = if (last == null) true
            else !senderName.isNullOrBlank() && !senderName.equals("You", true) && (self == null || senderName != self)
            val hasKey = x.containsKey("android.isGroupConversation")
            val groupFlag = x.getBoolean("android.isGroupConversation", false)
            val conv = x.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE)?.toString()
            val isGroup = groupFlag || !conv.isNullOrBlank()
            val summary = (n.flags and Notification.FLAG_GROUP_SUMMARY) != 0
            val verified = hasKey && !groupFlag && conv.isNullOrBlank() && fromOther && !summary
            val time = last?.getLong("time", sbn.postTime) ?: sbn.postTime
            val action = n.actions?.firstOrNull { a -> a.remoteInputs?.isNotEmpty() == true }
            return Incoming(sbn.packageName, sbn.key, senderName?.takeIf { it.isNotBlank() } ?: title, text, time,
                fromOther, isGroup, verified, conv, action)
        }
    }
}
