import http from 'node:http';
import fs from 'node:fs';

const {
  GEMINI_API_KEY, GEMINI_MODEL = 'gemini-3.8-flash',
  WA_TOKEN, WA_PHONE_ID, VERIFY_TOKEN,
  OWNER_NAME = 'Ahsan Raza', PORT = 3000,
  ALLOWED_NUMBERS = '', DISCLOSE_IF_ASKED = 'true'
} = process.env;

const DB = 'memory.json';
let db = {};
try { db = JSON.parse(fs.readFileSync(DB, 'utf8')); } catch {}
const save = () => fs.writeFileSync(DB, JSON.stringify(db));
const knowledge = () => { try { return fs.readFileSync('knowledge.md', 'utf8'); } catch { return ''; } };
const sleep = ms => new Promise(r => setTimeout(r, ms));
const allowed = ALLOWED_NUMBERS.split(',').map(s => s.trim()).filter(Boolean);

async function gemini(system, contents) {
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_MODEL}:generateContent`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': GEMINI_API_KEY },
    body: JSON.stringify({
      system_instruction: { parts: [{ text: system }] },
      contents,
      generationConfig: { temperature: 0.9, maxOutputTokens: 1024 }
    })
  });
  const d = await r.json();
  if (d.error) throw new Error(d.error.message);
  return (d.candidates?.[0]?.content?.parts || []).map(p => p.text || '').join('').trim();
}

function persona(u) {
  return `Tum ${OWNER_NAME} ho aur WhatsApp par apne jaanne walon se baat kar rahe ho. Bilkul insan ki tarah baat karo.
Rules:
- Jitna poocha jaye utna hi jawab do. Chhota sawal = chhota jawab. "hey" ka jawab "hey", "a.o.a" ya "assalamualaikum" ka jawab "walaikum assalam".
- Usi zabaan aur style me likho jis me samne wala likhe (Roman Urdu, Hinglish ya English). Aksar ek ya do chhoti lines, emoji kam.
- Robotic mat bano. "How can I help you", lists, headings, bullet points kabhi nahi.
- Jo cheez nahi pata uska andaza mat lagao. Kaho "yaar mujhe pata nahi" ya "baad me batata hoon".
- Samne wale ne jo bataya wo yaad rakho aur zarurat par naturally zikr karo.
- OTP, password, paisay bhejna ya koi risky cheez kabhi mat do. Kaho "main baad me khud baat karta hoon".
- Knowledge base ki baat sirf tab batao jab uske baare me poochha jaye, khud se mat ugalo.
${DISCLOSE_IF_ASKED === 'true' ? `- Agar koi sanjeedgi se poochhe ke tum bot ya AI ho, jhoot mat bolo. Batao ke ye ${OWNER_NAME} ka auto-reply assistant hai.` : ''}

Meri jaankari (knowledge base):
${knowledge()}

Is shakhs (${u.name || 'unknown'}) ke baare me yaad dasht:
${u.notes || '(abhi kuch nahi)'}`;
}

async function wa(body) {
  const r = await fetch(`https://graph.facebook.com/v21.0/${WA_PHONE_ID}/messages`, {
    method: 'POST',
    headers: { Authorization: `Bearer ${WA_TOKEN}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ messaging_product: 'whatsapp', ...body })
  });
  if (!r.ok) console.error('WhatsApp error', await r.text());
}

async function updateNotes(u) {
  const recent = u.hist.slice(-10).map(m => `${m.role === 'user' ? 'Samne wala' : 'Main'}: ${m.parts[0].text}`).join('\n');
  const out = await gemini(
    'Tum note-taker ho. Purane notes aur nayi baatcheet se is shakhs ke baare me sirf pakki baatein (naam, kaam, pasand, wade, dates, ghar walon ke naam) bullet lines me likho. Max 15 lines. Sirf notes likho.',
    [{ role: 'user', parts: [{ text: `Purane notes:\n${u.notes || '-'}\n\nBaatcheet:\n${recent}` }] }]
  );
  if (out) { u.notes = out; save(); }
}

const pending = {};
function queue(from, text, name, msgId) {
  const p = pending[from] ??= { texts: [], timer: null };
  p.texts.push(text);
  p.msgId = msgId;
  clearTimeout(p.timer);
  p.timer = setTimeout(() => { const t = p.texts.join('\n'); p.texts = []; handle(from, t, name, p.msgId).catch(e => console.error(e.message)); }, 3500);
}

async function handle(from, text, name, msgId) {
  const u = db[from] ??= { hist: [], notes: '', n: 0, name };
  u.hist.push({ role: 'user', parts: [{ text }] });
  u.hist = u.hist.slice(-40);
  while (u.hist[0]?.role === 'model') u.hist.shift();
  wa({ status: 'read', message_id: msgId, typing_indicator: { type: 'text' } }).catch(() => {});
  const reply = await gemini(persona(u), u.hist);
  if (!reply) return;
  u.hist.push({ role: 'model', parts: [{ text: reply }] });
  u.n++;
  save();
  await sleep(Math.min(1200 + reply.length * 45, 7000));
  await wa({ to: from, type: 'text', text: { body: reply } });
  if (u.n % 4 === 0) updateNotes(u).catch(() => {});
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://x');
  if (url.pathname !== '/webhook') { res.writeHead(200).end('Juliet bot chal raha hai'); return; }
  if (req.method === 'GET') {
    if (url.searchParams.get('hub.verify_token') === VERIFY_TOKEN) res.writeHead(200).end(url.searchParams.get('hub.challenge'));
    else res.writeHead(403).end();
    return;
  }
  let raw = '';
  for await (const c of req) raw += c;
  res.writeHead(200).end('ok');
  try {
    const v = JSON.parse(raw).entry?.[0]?.changes?.[0]?.value;
    const m = v?.messages?.[0];
    if (!m || m.type !== 'text') return;
    if (allowed.length && !allowed.includes(m.from)) return;
    queue(m.from, m.text.body, v.contacts?.[0]?.profile?.name, m.id);
  } catch (e) { console.error(e.message); }
}).listen(PORT, () => console.log('Juliet WhatsApp bot port', PORT));
