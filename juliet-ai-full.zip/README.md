# Juliet AI

Your AI assistant by Ahsan Raza. Voice aur chat assistant jo Gemini (aur Groq fallback) se jawab deti hai.

## Voice assistant (hands-free) — naya
Home par orb ya **Start listening** dabao. Juliet chalti rehti hai: **Listening → Thinking → Speaking → phir Listening**. Status orb ke neeche dikhta hai.
- Orb tap jab Juliet bol rahi ho = uski baat skip karke seedha sunna. **Stop listening** = poora band. Bolke bhi band kar sakte ho: "stop", "bas karo", "chup", "bye".
- Android APK me app khulte hi khud sunna shuru (Settings → "App khulte hi hands-free sunna"). Browser me pehli baar orb dabana padta hai (browser ki pabandi).
- Awaaz: ElevenLabs → Google TTS → **Gemini natural voice (Kore/Aoede/Zephyr/Leda/Sulafat)** → phone ki awaaz. Language: Auto/Hindi/Hinglish/Urdu/English.
- App background me jaye to sunna ruk jata hai; wapas aate hi chalu. "Hey Juliet" background service in-app sunte waqt khud pause hoti hai aur baad me wapas chalti hai.
- **Settings → Keys test karo** se har API key ek click me check hoti hai (✓/✗ aur error).

**Gemini model:** default ab `gemini-3.8-flash` hai. Agar Google koi model band kare to app khud agla model try karti hai (3.7, 3.5). Settings → Gemini model me apna model bhi likh sakte ho.

## Phone control (Android APK)
Settings → Permissions me har cheez ka **Allow** button hai (Mic, Call, SMS, Contacts, Phone state, Notifications, **Accessibility**, **Notification access**, Battery). Allow dabao → Android ki screen me ON karo → wapas aao, tick ✓ ho jata hai.
Awaaz se: call, SMS, WhatsApp, app kholo (naam se), back, home, recents, notification shade, quick settings, lock, screenshot, scroll up/down, "click <text>", "type <text>", screen padho, volume, torch, alarm, timer, battery, notifications padho/saaf karo.
Android 13+ par sideload APK me Accessibility/SMS "restricted" ho sakte hain: App info → ⋮ → **Allow restricted settings**.

## Kya kya hai
- `app/`: web app (PWA). Chat, voice, personalities, yaadasht, knowledge base, contacts, weather.
- `whatsapp-bot/`: WhatsApp par insani andaz me Gemini reply bot (alag README andar hai).
- `.github/workflows/`: GitHub Pages deploy aur Android APK build.

## GitHub par chalane ke steps
1. Naya repo banao aur is poore folder ki files upload karo (branch `main`).
2. **Web app:** Settings → Pages → Source: **GitHub Actions**. Push ke baad link milega: `https://USERNAME.github.io/REPO/`.
3. **Android APK:** Actions tab → **Build Android APK** → Run workflow. Khatam hone par Artifacts me `Juliet-AI-apk` download karo aur phone me install karo.
4. App kholo → Settings → Gemini API key daalo (aistudio.google.com/apikey) → Save karo.

## Features jo kaam karte hain
- **AI providers:** Gemini, Groq, OpenRouter, OpenAI, Claude, DeepSeek, Mistral, Together, NVIDIA NIM aur koi bhi OpenAI-compatible custom endpoint. Jitni keys daaloge utne chalenge. Provider order: Best pehle (ek fail to agla), Ranked (baari baari), Sab ek saath (jo pehle jawab de). Model ka naam Settings → Model names me badal sakte ho.
- Chat yaadasht, 9 personalities, knowledge base, user ke baare me notes.
- **Voice input:** Android me Google ka mic dialog, Chrome me browser mic, ya Deepgram key se. **Voice output:** ElevenLabs, Google Cloud TTS, ya phone ki apni TTS.
- **Phone actions:** call, SMS, WhatsApp, app kholna, search, map. Juliet button deti hai, tap karne par kaam hota hai. Contacts: Settings → Contacts me `Naam=number`.
- Mausam card (OpenWeather key se).

## Android app ke native features (APK me hi chalte hain)
Settings → **Hey Juliet** section me:
1. **Permissions allow karo** dabao (mic, call, SMS, contacts, phone state, notifications).
2. **“Hey Juliet” background me sunna** on karo. Notification dikhegi ke Juliet sun rahi hai.
3. Bolo: “Juliet, Papa ko call karo” ya “Juliet, Mummy ko SMS karo late aaunga”. Gemini jawab deti hai aur kaam khud karti hai: call (seedha), SMS (seedha bhejti hai).
4. **Incoming call:** Juliet naam bolti hai, “Uthaoon ya kaat doon?” poochti hai. “Uthao” bolo to uthati hai, “kaat do” bolo to kaat deti hai.
5. Chat me call/SMS ka button ab seedha call/SMS karta hai.

Native service sirf **Gemini key** use karti hai (jo app me Save ki ho). Contacts pehle Settings ki list se, phir phone ke contacts se dhoondhti hai.

## Limits (Android ki wajah se)
- Wake word Android ke apne speech recognizer se pakda jata hai, isliye kabhi kabhi beep aata hai aur kabhi “Juliet” miss ho sakta hai. Battery saver me service band ho sakti hai: App info → Battery → Unrestricted karo.
- Android 10+ background se app/website seedha nahi khulti. Isliye YouTube, WhatsApp, search, map ke liye Juliet notification bhejti hai, usko tap karo.
- Call uthana/kaatna sab phones par ek jaisa nahi chalta (Android version aur company par depend). Pehle test karo.
- Picovoice, Twilio aur Google Maps keys abhi connect nahi hain.

## Agar APK build fail ho
Actions → fail hui run → log copy karke bhejo. Native code `android-native/` me hai aur build ke waqt `scripts/patch_android.py` use android project me lagata hai.

## Local chalana
`npm run serve` phir `http://localhost:8080`.

## Privacy
API keys aur chats sirf device ke local storage me rehti hain. Repo me kabhi keys commit mat karo.
