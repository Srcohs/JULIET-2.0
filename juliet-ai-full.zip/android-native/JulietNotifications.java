package com.ahsanraza.juliet;

import android.app.Notification;
import android.content.Context;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

/** Notifications padhne aur saaf karne ke liye (Notification access allow hone par). */
public class JulietNotifications extends NotificationListenerService {
  static volatile JulietNotifications INSTANCE;

  @Override
  public void onListenerConnected() {
    INSTANCE = this;
  }

  @Override
  public void onListenerDisconnected() {
    INSTANCE = null;
  }

  static String appName(Context c, String pkg) {
    try {
      android.content.pm.PackageManager pm = c.getPackageManager();
      return pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
    } catch (Exception e) {
      return pkg;
    }
  }

  static String recent(Context c) {
    JulietNotifications s = INSTANCE;
    if (s == null) return null;
    StatusBarNotification[] a = s.getActiveNotifications();
    if (a == null || a.length == 0) return "Koi notification nahi hai.";
    StringBuilder sb = new StringBuilder();
    int n = 0;
    for (int i = a.length - 1; i >= 0 && n < 5; i--) {
      Notification nt = a[i].getNotification();
      if (nt == null || nt.extras == null) continue;
      if (a[i].getPackageName().equals(c.getPackageName())) continue;
      CharSequence title = nt.extras.getCharSequence(Notification.EXTRA_TITLE);
      CharSequence text = nt.extras.getCharSequence(Notification.EXTRA_TEXT);
      if (title == null && text == null) continue;
      sb.append(appName(c, a[i].getPackageName())).append(": ")
          .append(title == null ? "" : title).append(" ")
          .append(text == null ? "" : text).append(". ");
      n++;
    }
    return n == 0 ? "Koi nayi notification nahi hai." : sb.toString();
  }

  static boolean clearAll() {
    JulietNotifications s = INSTANCE;
    if (s == null) return false;
    s.cancelAllNotifications();
    return true;
  }
}
