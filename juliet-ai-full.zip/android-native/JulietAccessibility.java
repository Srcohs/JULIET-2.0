package com.ahsanraza.juliet;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.List;

/** Awaaz se phone control: back, home, scroll, tap, type, screen padhna. */
public class JulietAccessibility extends AccessibilityService {
  static volatile JulietAccessibility INSTANCE;

  @Override
  protected void onServiceConnected() {
    INSTANCE = this;
  }

  @Override
  public void onAccessibilityEvent(AccessibilityEvent e) {}

  @Override
  public void onInterrupt() {}

  @Override
  public boolean onUnbind(android.content.Intent i) {
    INSTANCE = null;
    return super.onUnbind(i);
  }

  @Override
  public void onDestroy() {
    INSTANCE = null;
    super.onDestroy();
  }

  boolean scroll(boolean down) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root != null) {
      AccessibilityNodeInfo n = findScrollable(root);
      if (n != null) {
        int act = down ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD;
        if (n.performAction(act)) return true;
      }
    }
    return swipe(down);
  }

  AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n) {
    if (n == null) return null;
    if (n.isScrollable()) return n;
    for (int i = 0; i < n.getChildCount(); i++) {
      AccessibilityNodeInfo r = findScrollable(n.getChild(i));
      if (r != null) return r;
    }
    return null;
  }

  boolean swipe(boolean down) {
    try {
      android.util.DisplayMetrics m = getResources().getDisplayMetrics();
      float x = m.widthPixels / 2f;
      float y1 = m.heightPixels * (down ? 0.7f : 0.3f);
      float y2 = m.heightPixels * (down ? 0.3f : 0.7f);
      Path p = new Path();
      p.moveTo(x, y1);
      p.lineTo(x, y2);
      GestureDescription.Builder b = new GestureDescription.Builder();
      b.addStroke(new GestureDescription.StrokeDescription(p, 0, 300));
      return dispatchGesture(b.build(), null, null);
    } catch (Exception e) {
      return false;
    }
  }

  boolean clickText(String text) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null || text == null || text.isEmpty()) return false;
    List<AccessibilityNodeInfo> l = root.findAccessibilityNodeInfosByText(text);
    if (l == null) return false;
    for (AccessibilityNodeInfo n : l) {
      AccessibilityNodeInfo c = n;
      while (c != null && !c.isClickable()) c = c.getParent();
      if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true;
    }
    return false;
  }

  boolean typeText(String text) {
    AccessibilityNodeInfo root = getRootInActiveWindow();
    if (root == null) return false;
    AccessibilityNodeInfo f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
    if (f == null) return false;
    Bundle b = new Bundle();
    b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
    return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
  }

  String readScreen() {
    StringBuilder sb = new StringBuilder();
    collect(getRootInActiveWindow(), sb, 0);
    return sb.toString().trim();
  }

  void collect(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
    if (n == null || sb.length() > 700 || depth > 30) return;
    CharSequence t = n.getText();
    if (t != null && t.length() > 0) {
      sb.append(t).append(". ");
    } else {
      CharSequence d = n.getContentDescription();
      if (d != null && d.length() > 0) sb.append(d).append(". ");
    }
    for (int i = 0; i < n.getChildCount(); i++) collect(n.getChild(i), sb, depth + 1);
  }
}
