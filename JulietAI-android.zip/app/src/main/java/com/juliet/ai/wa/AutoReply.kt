package com.juliet.ai.wa

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.RemoteInput
import android.content.Context
import android.content.Intent
import android.os.Bundle
import com.juliet.ai.BuildConfig
import com.juliet.ai.data.Knowledge
import com.juliet.ai.data.Prefs
import com.juliet.ai.net.GroqClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * WhatsApp auto-reply for private chats only.
 * Order of checks: chat type (before any AI or memory) > duplicates > manual takeover > cooldown > reply.
 */
class AutoReply(private val ctx: Context, private val prefs: Prefs) {
    class Reply(val text: String, val handover: Boolean)

    private val groq = GroqClient()
    private val knowledge = Knowledge(prefs)
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val processed = LinkedHashSet<String>()
    private val manualUntil = ConcurrentHashMap<String, Long>()
    private val awaiting = ConcurrentHashMap<String, Long>()
    private val lastReply = ConcurrentHashMap<String, Long>()
    private val greetedAt = ConcurrentHashMap<String, Long>()
    private val history = ConcurrentHashMap<String, MutableList<GroqClient.Msg>>()

    private val greet = Regex("(?i)(assalam\\w*(\\s*o?\\s*alaikum)?|a?salam\\s*o\\s*alaikum|aslam\\s*o\\s*alaikum|salaam|salam|\\baoa\\b|a\\.o\\.a|السلام\\s*علیکم|السلام\\s*عليكم|سلام)")

    fun handle(inc: Incoming) {
        // 1. Strict chat-type filter FIRST. Groups, channels and unverified chats stop here: no AI, no memory, no reply.
        if (!inc.verifiedPrivate) return
        val action = inc.replyAction ?: return
        if (inc.sender.isBlank() || inc.text.isBlank()) return
        // 2. One eligible response per message.
        synchronized(processed) {
            if (!processed.add(inc.id)) return
            if (processed.size > 300) processed.remove(processed.first())
        }
        val now = System.currentTimeMillis()
        // 3. Someone (Ahsan) already looked at this chat.
        if ((manualUntil[inc.sender] ?: 0L) > now) return
        // 4. Cooldown against loops and bursts.
        if ((lastReply[inc.sender] ?: 0L) + 4000L > now) return
        scope.launch { respond(inc, action) }
    }

    /** The user opened or dismissed this chat's notification: treat it as a manual takeover for a while. */
    fun markManual(sender: String) {
        manualUntil[sender] = System.currentTimeMillis() + 10 * 60_000L
        awaiting.remove(sender)
    }

    private suspend fun respond(inc: Incoming, action: Notification.Action) {
        val who = inc.sender
        val hist = history.getOrPut(who) { mutableListOf() }
        synchronized(hist) { hist.add(GroqClient.Msg("user", inc.text)); while (hist.size > 12) hist.removeAt(0) }
        val reply = decide(who, inc.text, synchronized(hist) { hist.toList() }, true) ?: return
        delay((1200L..3000L).random())
        if ((manualUntil[who] ?: 0L) > System.currentTimeMillis()) return
        if (send(action, reply.text)) {
            lastReply[who] = System.currentTimeMillis()
            synchronized(hist) { hist.add(GroqClient.Msg("assistant", reply.text)) }
            if (reply.handover) { awaiting[who] = System.currentTimeMillis(); notifyOwner(who, inc.text) }
        }
    }

    suspend fun preview(sender: String, msg: String): String {
        val r = decide(sender, msg, listOf(GroqClient.Msg("user", msg)), false)
            ?: return "(Juliet would stay silent here)"
        return (if (r.handover) "[Would hand over to Ahsan] " else "") + r.text
    }

    private suspend fun decide(who: String, msg: String, hist: List<GroqClient.Msg>, record: Boolean): Reply? {
        val now = System.currentTimeMillis()
        val t = msg.trim()
        val waitSince = awaiting[who]
        if (record && waitSince != null && now - waitSince < 60 * 60_000L) return null   // already told them to wait
        val greetedRecently = (greetedAt[who] ?: 0L) + 6 * 3600_000L > now
        val hasGreeting = greet.containsMatchIn(t)
        if (hasGreeting) {
            val rest = greet.replace(t, "").replace(Regex("[\\p{Punct}\\s]+"), "")
            if (rest.length <= 12 && !t.contains('?') && !t.contains('؟')) {
                if (record) greetedAt[who] = now
                return Reply(if (greetedRecently) "وعلیکم السلام، جی فرمائیے۔" else "وعلیکم السلام ورحمة الله وبركاته", false)
            }
        }
        if (record && hasGreeting) greetedAt[who] = now
        val clock = SimpleDateFormat("EEEE h:mm a", Locale.ENGLISH).format(Date())
        val system = "You are Juliet, a polite personal assistant replying on WhatsApp on behalf of Ahsan, your owner. " +
            "Write like a helpful human assistant, in the same language and script as the sender (Urdu script, Roman Urdu, English or Arabic). " +
            "Answer the actual question. Keep simple replies to 1-3 short sentences; explain more only when needed. " +
            "Use ONLY the facts below and the conversation. Never invent facts, plans, availability, prices, promises or private details about Ahsan, and never present uncertain things as verified. " +
            "Work hours are context, not a rule for every reply. " +
            "If you cannot answer confidently, or the question needs Ahsan's own decision (money, commitments, meetings, private matters, anything unclear), reply with exactly: [HANDOVER]\n" +
            (if (hasGreeting && !greetedRecently) "The message contains a greeting plus a question: start with \"وعلیکم السلام ورحمة الله وبركاته\" then answer. "
            else "Do not repeat a greeting. ") +
            "Do not say you are an AI unless asked; if asked who you are, say you are Juliet, Ahsan's assistant.\n" +
            "Current local time: $clock.\nSender: $who\nFacts saved by Ahsan:\n${knowledge.promptFacts()}"
        val out = groq.chat(groqKeys(), system, hist).getOrNull()?.trim() ?: return null
        if (out.isBlank()) return null
        if (out.contains("[HANDOVER]")) return Reply(handoverText(t), true)
        return Reply(out, false)
    }

    private fun handoverText(msg: String): String {
        if (Regex("[\\u0600-\\u06FF]").containsMatchIn(msg)) return "براہ کرم انتظار کریں، احسن صاحب خود آپ کو جواب دیں گے۔"
        val english = Regex("(?i)\\b(the|is|are|you|what|when|how|please|can|do|does|where|why|which|will)\\b").containsMatchIn(msg)
        return if (english) "Please wait, sir. Ahsan will personally respond to you shortly."
        else "Please wait karein, Ahsan sir khud aapko jawab dein ge."
    }

    private fun groqKeys(): List<String> =
        prefs.get("k_groq").ifBlank { BuildConfig.DEFAULT_GROQ_KEYS }.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    /** Sends through the notification's own Reply action. Success means Android accepted it; delivery is not confirmed. */
    private fun send(action: Notification.Action, text: String): Boolean = try {
        val inputs = action.remoteInputs ?: return false
        val data = Bundle()
        for (r in inputs) data.putCharSequence(r.resultKey, text)
        val intent = Intent()
        RemoteInput.addResultsToIntent(inputs, intent, data)
        action.actionIntent.send(ctx, 0, intent)
        true
    } catch (e: Exception) { false }

    private fun notifyOwner(who: String, msg: String) {
        try {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("juliet_handover", "Juliet needs your reply", NotificationManager.IMPORTANCE_HIGH))
            val n = Notification.Builder(ctx, "juliet_handover").setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("$who needs your reply").setContentText(msg.take(120)).setAutoCancel(true).build()
            nm.notify(who.hashCode(), n)
        } catch (e: Exception) { }
    }
}
