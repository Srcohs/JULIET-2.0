package com.ahsanraza.juliet;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
  @Override
  public void onCreate(Bundle savedInstanceState) {
    registerPlugin(JulietNativePlugin.class);
    super.onCreate(savedInstanceState);
  }
}
