package com.juliet.ai.ann

import android.app.NotificationManager
import android.content.Context
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech

/** Speaks announcements. Skips them during calls, Juliet voice sessions, silent mode and Do Not Disturb. */
object Announcer {
    @Volatile var voiceActive = false          // set by GeminiLive while a voice session runs

    private class Item(val text: String, val vol: Float)
    private var tts: TextToSpeech? = null
    private var ready = false
    private val pending = ArrayDeque<Item>()

    /** Returns null if spoken or queued, otherwise the reason it was skipped. */
    @Synchronized
    fun speak(ctx: Context, text: String, volume: Float = 1f, force: Boolean = false): String? {
        val app = ctx.applicationContext
        if (!force) {
            val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            if (am.mode == AudioManager.MODE_IN_CALL || am.mode == AudioManager.MODE_IN_COMMUNICATION) return "a call is in progress"
            if (voiceActive) return "a Juliet voice session is active"
            if (am.ringerMode != AudioManager.RINGER_MODE_NORMAL) return "phone is on silent or vibrate"
            val nm = app.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val f = nm.currentInterruptionFilter
            if (f != NotificationManager.INTERRUPTION_FILTER_ALL && f != NotificationManager.INTERRUPTION_FILTER_UNKNOWN) return "Do Not Disturb is on"
        }
        val item = Item(text, volume.coerceIn(0f, 1f))
        if (tts == null) {
            tts = TextToSpeech(app) { st ->
                synchronized(this@Announcer) {
                    ready = st == TextToSpeech.SUCCESS
                    if (ready) { while (pending.isNotEmpty()) say(pending.removeFirst()) } else pending.clear()
                }
            }
        }
        if (ready) say(item) else pending.addLast(item)
        return null
    }

    private fun say(i: Item) {
        val b = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, i.vol) }
        tts?.speak(i.text, TextToSpeech.QUEUE_ADD, b, "ann" + System.nanoTime())
    }

    @Synchronized
    fun stop() { tts?.stop(); pending.clear() }
}
