package com.ahsanraza.juliet;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/** Service ke liye Gemini se seedha baat (app band ho tab bhi). */
public class Brain {
  static final List<String[]> hist = new ArrayList<>();

  static final java.util.Set<String> bad = new java.util.HashSet<>();

  static final String PHONE = "Agar user phone ka kaam bole to bahut chhota jawab likho aur sabse aakhir me ek line [[ACTION:{...}]] lagao (sirf ek ACTION). Types: {\"type\":\"call\",\"name\":\"Papa\"} | {\"type\":\"sms\",\"name\":\"Papa\",\"text\":\"...\"} | {\"type\":\"whatsapp\",\"name\":\"Papa\",\"text\":\"...\"} | {\"type\":\"open\",\"app\":\"youtube\"} | {\"type\":\"url\",\"url\":\"https://...\"} | {\"type\":\"search\",\"q\":\"...\"} | {\"type\":\"map\",\"q\":\"...\"} | Phone control: {\"type\":\"back\"} {\"type\":\"home\"} {\"type\":\"recents\"} {\"type\":\"notifications\"} (shade kholo) {\"type\":\"quicksettings\"} {\"type\":\"lock\"} {\"type\":\"screenshot\"} {\"type\":\"scroll\",\"dir\":\"down\"} (up ya down) {\"type\":\"click\",\"text\":\"Send\"} (screen par us naam wale button par tap) {\"type\":\"type\",\"text\":\"...\"} (khule text box me likho) {\"type\":\"read_screen\"} | {\"type\":\"volume\",\"dir\":\"up\"} (up/down/mute/max) {\"type\":\"flashlight\",\"on\":true} {\"type\":\"alarm\",\"hour\":7,\"minute\":30} {\"type\":\"timer\",\"seconds\":300} {\"type\":\"battery\"} {\"type\":\"read_notifications\"} {\"type\":\"clear_notifications\"}. Name wahi likho jo user ne bola. Phone ka kaam na ho to ACTION mat likho.";

  static String read(InputStream is) throws Exception {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    byte[] buf = new byte[4096];
    int n;
    while ((n = is.read(buf)) > 0) bo.write(buf, 0, n);
    return bo.toString("UTF-8");
  }

  static String strip(String t) {
    return t.replaceAll("(?s)\\[\\[ACTION:.*?\\]\\]", "").trim();
  }

  static String ask(Context c, String user) {
    SharedPreferences sp = c.getSharedPreferences("juliet", 0);
    String key = sp.getString("gemini", "");
    if (key.isEmpty()) return "Pehle app me Gemini key daalo aur Save karo.";
    String pref = sp.getString("model", "").trim().toLowerCase(java.util.Locale.ROOT).replace("models/", "").replace(" ", "-");
    String[] cands = {pref, "gemini-3.8-flash", "gemini-3.7-flash", "gemini-3.5-flash"};
    String model = "gemini-3.8-flash";
    for (String m : cands) {
      if (m.matches("[a-z0-9._-]+") && !bad.contains(m)) {
        model = m;
        break;
      }
    }
    String owner = sp.getString("owner", "Ahsan Raza");
    String system =
        "Tum Juliet ho, " + owner + " ka AI assistant. Personality: " + sp.getString("persona", "Normal")
            + ". Tum awaaz me bol rahi ho, isliye ek ya do chhote natural jawab do, bina lists ya symbols ke, usi zabaan me jo user bole (Roman Urdu, Hinglish ya English). "
            + "\n" + PHONE + "\nKnowledge base:\n" + sp.getString("kb", "");
    try {
      JSONArray contents = new JSONArray();
      synchronized (hist) {
        hist.add(new String[] {"user", user});
        while (hist.size() > 20) hist.remove(0);
        for (String[] h : hist) {
          contents.put(new JSONObject().put("role", h[0])
              .put("parts", new JSONArray().put(new JSONObject().put("text", h[1]))));
        }
      }
      JSONObject body = new JSONObject();
      body.put("system_instruction",
          new JSONObject().put("parts", new JSONArray().put(new JSONObject().put("text", system))));
      body.put("contents", contents);
      body.put("generationConfig", new JSONObject().put("maxOutputTokens", 512).put("temperature", 0.9));

      URL u = new URL("https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent");
      HttpURLConnection h = (HttpURLConnection) u.openConnection();
      h.setRequestMethod("POST");
      h.setRequestProperty("Content-Type", "application/json");
      h.setRequestProperty("x-goog-api-key", key);
      h.setDoOutput(true);
      h.setConnectTimeout(15000);
      h.setReadTimeout(30000);
      OutputStream os = h.getOutputStream();
      os.write(body.toString().getBytes("UTF-8"));
      os.close();
      int code = h.getResponseCode();
      InputStream is = code >= 400 ? h.getErrorStream() : h.getInputStream();
      JSONObject d = new JSONObject(read(is));
      if (d.has("error")) {
        dropLastUser();
        String em = d.getJSONObject("error").optString("message", "unknown");
        if (em.matches("(?is).*(no longer available|unexpected model|not found|not supported|deprecated).*") && bad.size() < 3) {
          bad.add(model);
          return ask(c, user);
        }
        return "Gemini error: " + em;
      }
      JSONArray parts = d.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts");
      StringBuilder sb = new StringBuilder();
      for (int i = 0; i < parts.length(); i++) sb.append(parts.getJSONObject(i).optString("text", ""));
      String text = sb.toString().trim();
      synchronized (hist) {
        hist.add(new String[] {"model", strip(text)});
      }
      return text;
    } catch (Exception e) {
      dropLastUser();
      return "Internet ya Gemini me masla hai.";
    }
  }

  static void dropLastUser() {
    synchronized (hist) {
      if (!hist.isEmpty() && hist.get(hist.size() - 1)[0].equals("user")) hist.remove(hist.size() - 1);
    }
  }
}
