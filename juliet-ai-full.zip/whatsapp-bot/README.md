# Juliet WhatsApp Bot (Gemini)

Ahsan Raza ki tarah insani andaz me jawab deta hai: chhota sawal, chhota jawab; "hey" par "hey"; "a.o.a" par "walaikum assalam"; har banday ki baatein yaad rakhta hai.

## Setup
1. Node 20.6 ya naya chahiye. Koi npm package nahi lagta.
2. `.env.example` ko `.env` naam se copy karo aur bharo:
   - GEMINI_API_KEY: aistudio.google.com/apikey se
   - WA_TOKEN, WA_PHONE_ID, VERIFY_TOKEN: developers.facebook.com me app banao, WhatsApp product add karo (Cloud API). Phone number ID aur token wahin milta hai.
3. `knowledge.md` me apni jaankari likho (job, Bhenso ki Rani wali detail, pasand na-pasand).
4. `npm start`
5. Server ko internet par https se do (Render, Railway, ya `cloudflared tunnel`), phir Meta app me Webhook URL `https://tumhara-domain/webhook` aur VERIFY_TOKEN daalo, aur `messages` field subscribe karo.

## Dhyan do
- Official Cloud API ke liye alag business number chahiye. Wo number saath me normal WhatsApp app me nahi chalta.
- Personal number par `whatsapp-web.js` ya Baileys jaisi unofficial libraries se auto-reply WhatsApp ki policy ke khilaf hai aur number ban ho sakta hai. Is liye maine unhe nahi use kiya.
- Yaadasht `memory.json` me hoti hai (har number ki last 40 messages aur notes). Isse private rakho.
- Bot OTP, password aur paisay ki baat par jawab nahi deta.
