package com.juliet.ai.screen

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean

/** Explicit-consent screen capture. Frames are downsampled and forwarded in memory; no recording is saved. */
class JulietScreenCaptureService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val processing = AtomicBoolean(false)
    private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        createChannel()
        val note = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setContentTitle("Juliet screen sharing is active")
            .setContentText("Screen frames are sent to Juliet Live AI until you stop sharing.")
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, note, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(NOTIF_ID, note)
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        val data = if (Build.VERSION.SDK_INT >= 33) intent.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                   else (intent.getParcelableExtra(EXTRA_DATA) as? Intent)
        if (resultCode != Activity.RESULT_OK || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = mgr.getMediaProjection(resultCode, data)
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val metrics = DisplayMetrics()
            @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(metrics)
            val scale = minOf(1f, 720f / metrics.widthPixels.toFloat())
            val w = (metrics.widthPixels * scale).toInt().coerceAtLeast(2) and -2
            val h = (metrics.heightPixels * scale).toInt().coerceAtLeast(2) and -2
            reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            display = projection?.createVirtualDisplay("JulietLiveScreen", w, h, metrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader?.surface, null, null)
            ScreenShareBridge.active = true
            reader?.setOnImageAvailableListener({ src ->
                val now = System.currentTimeMillis()
                if (now - lastFrameAt < 1200 || !processing.compareAndSet(false, true)) { src.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
                lastFrameAt = now
                try {
                    val img = src.acquireLatestImage() ?: return@setOnImageAvailableListener
                    img.use {
                        val plane = it.planes[0]; val buffer = plane.buffer
                        val pixelStride = plane.pixelStride; val rowStride = plane.rowStride
                        val rowPadding = rowStride - pixelStride * it.width
                        val bmp = android.graphics.Bitmap.createBitmap(it.width + rowPadding / pixelStride, it.height, android.graphics.Bitmap.Config.ARGB_8888)
                        bmp.copyPixelsFromBuffer(buffer)
                        val cropped = android.graphics.Bitmap.createBitmap(bmp, 0, 0, it.width, it.height)
                        bmp.recycle()
                        val out = ByteArrayOutputStream(); cropped.compress(android.graphics.Bitmap.CompressFormat.JPEG, 55, out); cropped.recycle()
                        ScreenShareBridge.publish(out.toByteArray())
                    }
                } catch (_: Exception) { } finally { processing.set(false) }
            }, null)
        } catch (_: Exception) { stopSelf(); return START_NOT_STICKY }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Juliet screen sharing", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onDestroy() {
        ScreenShareBridge.active = false
        display?.release(); display = null
        reader?.close(); reader = null
        try { projection?.stop() } catch (_: Exception) { }
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.juliet.ai.SCREEN_START"
        const val ACTION_STOP = "com.juliet.ai.SCREEN_STOP"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "result_data"
        const val CHANNEL = "juliet_screen_share"
        const val NOTIF_ID = 7341
    }
}
