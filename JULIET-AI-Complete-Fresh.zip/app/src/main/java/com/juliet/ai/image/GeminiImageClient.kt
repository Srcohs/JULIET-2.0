package com.juliet.ai.image

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiImageClient {
    private val client = OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build()

    suspend fun generate(apiKey: String, prompt: String, source: Bitmap? = null): Result<Bitmap> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) return@withContext Result.failure(IllegalStateException("Add a Gemini API key in Settings > Connections."))
        val models = listOf("gemini-2.5-flash-image", "gemini-2.0-flash-preview-image-generation")
        var last: Exception = IllegalStateException("Image generation failed")
        for (model in models) {
            try {
                val parts = org.json.JSONArray().put(JSONObject().put("text", if (source == null) "Create an original image based on this prompt. If it describes a sketch, make it a clean pencil sketch. Prompt: ${prompt.take(1800)}" else "Edit the supplied image according to this instruction. Preserve the main subject's identity and composition unless asked otherwise. For sketch requests, turn it into a clean pencil sketch. Instruction: ${prompt.take(1800)}"))
                if (source != null) {
                    val stream = ByteArrayOutputStream()
                    source.compress(Bitmap.CompressFormat.JPEG, 88, stream)
                    parts.put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP))))
                }
                val body = JSONObject()
                    .put("contents", org.json.JSONArray().put(JSONObject().put("parts", parts)))
                    .put("generationConfig", JSONObject().put("responseModalities", org.json.JSONArray().put("TEXT").put("IMAGE")))
                val req = Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
                    .post(body.toString().toRequestBody("application/json".toMediaType())).build()
                client.newCall(req).execute().use { response ->
                    val raw = response.body?.string().orEmpty()
                    if (!response.isSuccessful) { last = IllegalStateException("Gemini image API HTTP ${response.code}"); return@use }
                    val parts = JSONObject(raw).optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts")
                    if (parts != null) for (i in 0 until parts.length()) {
                        val inline = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                        val bytes = Base64.decode(inline.optString("data"), Base64.DEFAULT)
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp != null) return@withContext Result.success(bmp)
                    }
                    last = IllegalStateException("This Gemini model did not return image data. Check model access and API billing.")
                }
            } catch (e: Exception) { last = e }
        }
        Result.failure(last)
    }
}
