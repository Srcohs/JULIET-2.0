package com.juliet.ai.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import org.json.JSONArray
import org.json.JSONObject

/** Keys, settings and chats. Everything is encrypted at rest and never leaves the phone. */
class Prefs(ctx: Context) {
    private val sp: SharedPreferences = try {
        val mk = MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            ctx, "juliet_secure", mk,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        ctx.getSharedPreferences("juliet_plain", Context.MODE_PRIVATE)   // rare Keystore failure
    }

    fun get(k: String, d: String = ""): String = sp.getString(k, d) ?: d
    fun put(k: String, v: String) { sp.edit().putString(k, v).apply() }
    fun clear() { sp.edit().clear().apply() }

    fun loadConvs(): List<Conv> = try {
        val a = JSONArray(get("history", "[]"))
        (0 until a.length()).map { i ->
            val o = a.getJSONObject(i); val m = o.getJSONArray("m")
            Conv(o.getLong("id"), o.getString("t"), (0 until m.length()).map { j ->
                val x = m.getJSONObject(j); ChatMsg(x.getString("r"), x.getString("x"))
            })
        }
    } catch (e: Exception) { emptyList() }

    fun saveConvs(list: List<Conv>) {
        val a = JSONArray()
        list.forEach { c ->
            val m = JSONArray()
            c.msgs.forEach { m.put(JSONObject().put("r", it.role).put("x", it.text)) }
            a.put(JSONObject().put("id", c.id).put("t", c.title).put("m", m))
        }
        put("history", a.toString())
    }
}
