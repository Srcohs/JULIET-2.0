package com.juliet.ai.data

import org.json.JSONArray
import org.json.JSONObject

data class KEntry(val id: Long, val text: String, val enabled: Boolean)

/** Facts Ahsan saves in plain text. Stored encrypted. Every write is read back to confirm it really saved. */
class Knowledge(private val prefs: Prefs) {
    private val key = "knowledge"

    private fun parse(): List<KEntry> = try {
        val a = JSONArray(prefs.get(key, "[]"))
        (0 until a.length()).map { val o = a.getJSONObject(it); KEntry(o.getLong("id"), o.getString("t"), o.optBoolean("e", true)) }
    } catch (e: Exception) { emptyList() }

    private fun write(list: List<KEntry>): Boolean {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("id", it.id).put("t", it.text).put("e", it.enabled)) }
        val s = a.toString()
        prefs.put(key, s)
        return prefs.get(key) == s
    }

    fun all(): List<KEntry> {
        if (prefs.get(key, "").isEmpty()) {
            val n = System.currentTimeMillis()
            write(listOf(
                KEntry(n, "Owner name: Ahsan.", true),
                KEntry(n + 1, "Ahsan's usual work schedule is 9:30 AM to 5:00 PM. After 5:00 PM he is generally not at his job. This is context only, not a rule that every message gets the same reply.", true)
            ))
        }
        return parse()
    }

    fun add(text: String): KEntry? {
        val t = text.trim()
        if (t.isEmpty() || t.length > 1500) return null
        val cur = all()
        if (cur.any { it.text.equals(t, true) }) return null
        val e = KEntry(System.currentTimeMillis(), t, true)
        return if (write(listOf(e) + cur)) e else null
    }

    fun update(id: Long, text: String): Boolean {
        val t = text.trim(); if (t.isEmpty() || t.length > 1500) return false
        val cur = all(); if (cur.none { it.id == id }) return false
        return write(cur.map { if (it.id == id) it.copy(text = t) else it })
    }

    fun delete(id: Long): Boolean { val cur = all(); return cur.any { it.id == id } && write(cur.filter { it.id != id }) }

    fun setEnabled(id: Long, on: Boolean): Boolean = write(all().map { if (it.id == id) it.copy(enabled = on) else it })

    /** All enabled facts, so the language model can pick the relevant ones for any wording of a question. */
    fun promptFacts(): String {
        val sb = StringBuilder()
        for (e in all().filter { it.enabled }) {
            if (sb.length + e.text.length > 6000) break
            sb.append("- ").append(e.text).append('\n')
        }
        return sb.toString().ifBlank { "- (nothing saved yet)" }
    }
}
