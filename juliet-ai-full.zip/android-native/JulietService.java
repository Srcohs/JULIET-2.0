package com.ahsanraza.juliet;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;
import androidx.core.app.NotificationCompat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

/**
 * "Hey Juliet" sunne wali foreground service.
 * WAKE: "Juliet ..." sunta hai. COMMAND: hukm sunta hai. BUSY: Gemini se jawab le raha hai.
 * CALL_ANSWER: incoming call par "uthaoon ya kaat doon?" poochta hai.
 */
public class JulietService extends Service implements TextToSpeech.OnInitListener {
  static volatile boolean RUNNING = false;

  static final String CH_LISTEN = "juliet_listen";
  static final String CH_ACTION = "juliet_action";
  static final String[] WAKE = {"juliette", "juliet", "julie", "जूलियट", "जुलियट", "जूली"};
  static final String[] YES = {"haan", "han ", "uthao", "utha", "uthalo", "pick", "answer", "yes", "receive", "हाँ", "हां", "उठाओ", "उठा"};
  static final String[] NO = {"nahi", "nahin", "nhi", "kaat", "kaato", "cut", "reject", "decline", "no", "band", "नहीं", "कट", "काट"};
  static final Pattern ACT = Pattern.compile("\\[\\[ACTION:(.*?)\\]\\]", Pattern.DOTALL);

  enum Mode { WAKE, COMMAND, BUSY, CALL_ANSWER }

  Handler main = new Handler(Looper.getMainLooper());
  SpeechRecognizer sr;
  TextToSpeech tts;
  boolean ttsReady = false;
  boolean alive = false;
  boolean speaking = false;
  boolean ringing = false;
  boolean announced = false;
  boolean timerSet = false;
  boolean inCall = false;
  int notifId = 100;
  Mode mode = Mode.WAKE;
  Runnable afterSpeech = null;

  final Runnable listenRun = new Runnable() {
    @Override
    public void run() {
      listen();
    }
  };

  // ---------- lifecycle ----------

  @Override
  public IBinder onBind(Intent intent) {
    return null;
  }

  @Override
  public void onCreate() {
    super.onCreate();
    createChannels();
    android.app.Notification n = baseNotification();
    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
    } else {
      startForeground(1, n);
    }
    alive = true;
    RUNNING = true;
    tts = new TextToSpeech(this, this);
    IntentFilter f = new IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);
    if (Build.VERSION.SDK_INT >= 33) registerReceiver(callRx, f, Context.RECEIVER_EXPORTED);
    else registerReceiver(callRx, f);
  }

  @Override
  public int onStartCommand(Intent intent, int flags, int startId) {
    listenLater(1000);
    return START_STICKY;
  }

  @Override
  public void onDestroy() {
    alive = false;
    RUNNING = false;
    main.removeCallbacksAndMessages(null);
    try {
      unregisterReceiver(callRx);
    } catch (Exception e) {
      // ignore
    }
    destroyRecognizer();
    if (tts != null) {
      tts.stop();
      tts.shutdown();
    }
    super.onDestroy();
  }

  @Override
  public void onInit(int status) {
    if (status == TextToSpeech.SUCCESS && tts != null) {
      int r = tts.setLanguage(new Locale("en", "IN"));
      if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) tts.setLanguage(Locale.US);
      tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
        @Override
        public void onStart(String id) {}

        @Override
        public void onDone(String id) {
          speechFinished();
        }

        @Override
        public void onError(String id) {
          speechFinished();
        }
      });
      ttsReady = true;
    }
  }

  // ---------- notifications ----------

  void createChannels() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
      nm.createNotificationChannel(new NotificationChannel(CH_LISTEN, "Juliet sun rahi hai", NotificationManager.IMPORTANCE_LOW));
      nm.createNotificationChannel(new NotificationChannel(CH_ACTION, "Juliet ke kaam", NotificationManager.IMPORTANCE_HIGH));
    }
  }

  android.app.Notification baseNotification() {
    Intent open = getPackageManager().getLaunchIntentForPackage(getPackageName());
    PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
    return new NotificationCompat.Builder(this, CH_LISTEN)
        .setContentTitle("Juliet sun rahi hai")
        .setContentText("\"Hey Juliet\" bolo")
        .setSmallIcon(android.R.drawable.ic_btn_speak_now)
        .setContentIntent(pi)
        .setOngoing(true)
        .build();
  }

  void notifyAction(String label, Intent i) {
    try {
      PendingIntent pi = PendingIntent.getActivity(this, notifId, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
      android.app.Notification n = new NotificationCompat.Builder(this, CH_ACTION)
          .setContentTitle("Juliet")
          .setContentText(label + " (tap karo)")
          .setSmallIcon(android.R.drawable.ic_btn_speak_now)
          .setContentIntent(pi)
          .setPriority(NotificationCompat.PRIORITY_HIGH)
          .setAutoCancel(true)
          .build();
      ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).notify(notifId++, n);
    } catch (Exception e) {
      // ignore
    }
  }

  // ---------- speech recognition ----------

  final RecognitionListener rl = new RecognitionListener() {
    @Override
    public void onReadyForSpeech(Bundle params) {}

    @Override
    public void onBeginningOfSpeech() {}

    @Override
    public void onRmsChanged(float rmsdB) {}

    @Override
    public void onBufferReceived(byte[] buffer) {}

    @Override
    public void onEndOfSpeech() {}

    @Override
    public void onPartialResults(Bundle partialResults) {}

    @Override
    public void onEvent(int eventType, Bundle params) {}

    @Override
    public void onResults(Bundle results) {
      ArrayList<String> r = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
      String text = (r != null && !r.isEmpty()) ? r.get(0) : "";
      onHeard(text);
    }

    @Override
    public void onError(int error) {
      if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
        stopSelf();
        return;
      }
      if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT
          || error == SpeechRecognizer.ERROR_SERVER) {
        destroyRecognizer();
      }
      boolean quiet = error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT;
      if (mode == Mode.COMMAND && quiet) mode = Mode.WAKE;
      if (speaking || mode == Mode.BUSY) return;
      listenLater(quiet ? 300 : 1500);
    }
  };

  void listenLater(long ms) {
    main.removeCallbacks(listenRun);
    main.postDelayed(listenRun, ms);
  }

  void listen() {
    if (!alive || speaking || inCall || mode == Mode.BUSY) return;
    try {
      if (sr == null) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
          stopSelf();
          return;
        }
        sr = SpeechRecognizer.createSpeechRecognizer(this);
        sr.setRecognitionListener(rl);
      }
      Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
      i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
      i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN");
      i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
      i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
      sr.startListening(i);
    } catch (Exception e) {
      destroyRecognizer();
      listenLater(2000);
    }
  }

  void cancelRecognizer() {
    if (sr != null) {
      try {
        sr.cancel();
      } catch (Exception e) {
        // ignore
      }
    }
  }

  void destroyRecognizer() {
    if (sr != null) {
      try {
        sr.destroy();
      } catch (Exception e) {
        // ignore
      }
      sr = null;
    }
  }

  // ---------- speaking ----------

  void say(final String text, final Runnable after) {
    main.post(new Runnable() {
      @Override
      public void run() {
        speaking = true;
        afterSpeech = after;
        cancelRecognizer();
        if (!ttsReady || tts == null) {
          speechFinished();
          return;
        }
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime());
      }
    });
  }

  void speechFinished() {
    main.post(new Runnable() {
      @Override
      public void run() {
        speaking = false;
        Runnable a = afterSpeech;
        afterSpeech = null;
        if (a != null) a.run();
        else listenLater(300);
      }
    });
  }

  // ---------- understanding what was heard ----------

  void onHeard(String text) {
    String t = text.toLowerCase(Locale.ROOT).trim();
    if (mode == Mode.CALL_ANSWER) {
      handleCallAnswer(t);
      return;
    }
    if (mode == Mode.COMMAND) {
      if (t.isEmpty()) {
        mode = Mode.WAKE;
        listenLater(300);
      } else {
        runCommand(text);
      }
      return;
    }
    int end = -1;
    for (String w : WAKE) {
      int i = t.indexOf(w);
      if (i >= 0) {
        end = i + w.length();
        break;
      }
    }
    if (end < 0) {
      listenLater(200);
      return;
    }
    String rest = t.substring(end).replaceFirst("^[,\\s]+", "");
    if (rest.length() >= 3) {
      runCommand(rest);
    } else {
      mode = Mode.COMMAND;
      say("Ji, boliye.", null);
    }
  }

  void runCommand(final String cmd) {
    mode = Mode.BUSY;
    cancelRecognizer();
    new Thread(new Runnable() {
      @Override
      public void run() {
        final String reply = Brain.ask(JulietService.this, cmd);
        main.post(new Runnable() {
          @Override
          public void run() {
            finishReply(reply);
          }
        });
      }
    }).start();
  }

  void finishReply(String reply) {
    String spoken = ACT.matcher(reply).replaceAll("").trim();
    if (spoken.isEmpty()) spoken = "Theek hai.";
    Matcher m = ACT.matcher(reply);
    String extra = null;
    if (m.find()) extra = doAction(m.group(1));
    mode = Mode.WAKE;
    say(extra != null ? spoken + " " + extra : spoken, null);
  }

  // ---------- phone actions ----------

  String doAction(String json) {
    try {
      JSONObject a = new JSONObject(json);
      String t = a.optString("type");
      String name = a.optString("name");
      String text = a.optString("text");
      if (t.equals("call")) {
        String n = Tools.number(this, name);
        if (n == null) return name + " ka number nahi mila.";
        if (!Tools.call(this, n)) openUri("tel:" + n, name + " ko call karo");
        return null;
      }
      if (t.equals("sms")) {
        String n = Tools.number(this, name);
        if (n == null) return name + " ka number nahi mila.";
        return Tools.sms(this, n, text) ? "SMS bhej diya." : "SMS nahi ja saka, permission check karo.";
      }
      if (t.equals("whatsapp")) {
        String n = Tools.number(this, name);
        if (n == null) return name + " ka number nahi mila.";
        openUri("https://wa.me/" + n.replace("+", "") + "?text=" + Uri.encode(text), name + " ko WhatsApp");
        return null;
      }
      if (t.equals("open")) {
        openUri(appUrl(a.optString("app")), a.optString("app") + " kholo");
        return null;
      }
      if (t.equals("url")) {
        String u = a.optString("url");
        if (u.startsWith("http")) openUri(u, "Link kholo");
        return null;
      }
      if (t.equals("search")) {
        openUri("https://www.google.com/search?q=" + Uri.encode(a.optString("q")), a.optString("q"));
        return null;
      }
      if (t.equals("map")) {
        openUri("https://www.google.com/maps/search/" + Uri.encode(a.optString("q")), a.optString("q"));
        return null;
      }
      return Actions.run(this, a);
    } catch (Exception e) {
      // ignore
    }
    return null;
  }

  String appUrl(String app) {
    String k = app == null ? "" : app.toLowerCase(Locale.ROOT).trim();
    switch (k) {
      case "youtube": return "https://www.youtube.com";
      case "whatsapp": return "https://wa.me/";
      case "instagram": return "https://www.instagram.com";
      case "facebook": return "https://www.facebook.com";
      case "gmail": return "https://mail.google.com";
      case "maps": return "https://maps.google.com";
      case "spotify": return "https://open.spotify.com";
      case "tiktok": return "https://www.tiktok.com";
      case "chrome": return "https://www.google.com";
      default: return "https://www.google.com/search?q=" + Uri.encode(k);
    }
  }

  /** Android 10+ background se activity nahi khulti, isliye notification bhi bhejte hain. */
  void openUri(String uri, String label) {
    Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    try {
      startActivity(i);
    } catch (Exception e) {
      // ignore
    }
    notifyAction(label, i);
  }

  // ---------- incoming calls ----------

  final BroadcastReceiver callRx = new BroadcastReceiver() {
    @Override
    public void onReceive(Context c, Intent i) {
      String st = i.getStringExtra(TelephonyManager.EXTRA_STATE);
      if (st == null) return;
      if (TelephonyManager.EXTRA_STATE_RINGING.equals(st)) {
        SharedPreferences sp = getSharedPreferences("juliet", 0);
        if (sp.getString("announce", "1").equals("0")) return;
        ringing = true;
        String num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
        if (num != null && !announced) {
          announced = true;
          announceCall(num);
        } else if (num == null && !announced && !timerSet) {
          timerSet = true;
          main.postDelayed(new Runnable() {
            @Override
            public void run() {
              if (ringing && !announced) {
                announced = true;
                announceCall(null);
              }
            }
          }, 1200);
        }
      } else if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(st)) {
        ringing = false;
        announced = false;
        timerSet = false;
        inCall = true;
        cancelRecognizer();
      } else {
        ringing = false;
        announced = false;
        timerSet = false;
        inCall = false;
        if (mode == Mode.CALL_ANSWER) mode = Mode.WAKE;
        listenLater(1500);
      }
    }
  };

  void announceCall(String num) {
    String name = Tools.nameOf(this, num);
    String who = name != null ? name : ((num != null && !num.isEmpty()) ? "number " + num.replaceAll("(.)", "$1 ") : "ek unknown number");
    mode = Mode.CALL_ANSWER;
    say(who + " ka call aa raha hai. Uthaoon ya kaat doon?", null);
  }

  boolean any(String t, String[] words) {
    for (String w : words) if (t.contains(w)) return true;
    return false;
  }

  void handleCallAnswer(String t) {
    if (!ringing) {
      mode = Mode.WAKE;
      listenLater(500);
      return;
    }
    if (any(t, NO)) {
      endCall();
      mode = Mode.WAKE;
      say("Theek hai, call kaat diya.", null);
    } else if (any(t, YES)) {
      acceptCall();
      mode = Mode.WAKE;
      inCall = true;
      cancelRecognizer();
    } else {
      say("Samajh nahi aaya. Uthaoon ya kaat doon?", null);
    }
  }

  void acceptCall() {
    try {
      if (Build.VERSION.SDK_INT >= 26 && Tools.has(this, Manifest.permission.ANSWER_PHONE_CALLS)) {
        ((TelecomManager) getSystemService(Context.TELECOM_SERVICE)).acceptRingingCall();
      }
    } catch (Exception e) {
      // ignore
    }
  }

  void endCall() {
    try {
      if (Build.VERSION.SDK_INT >= 28 && Tools.has(this, Manifest.permission.ANSWER_PHONE_CALLS)) {
        ((TelecomManager) getSystemService(Context.TELECOM_SERVICE)).endCall();
      }
    } catch (Exception e) {
      // ignore
    }
  }
}
