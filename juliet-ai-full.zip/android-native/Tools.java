package com.ahsanraza.juliet;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.telecom.TelecomManager;
import android.telephony.SmsManager;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Locale;

public class Tools {
  static boolean has(Context c, String perm) {
    return ContextCompat.checkSelfPermission(c, perm) == PackageManager.PERMISSION_GRANTED;
  }

  static String digits(String s) {
    return s == null ? "" : s.replaceAll("[^0-9+]", "");
  }

  /** Naam se number: pehle Settings ki contacts list, phir phone ke contacts. */
  static String number(Context c, String name) {
    if (name == null || name.trim().isEmpty()) return null;
    String n = name.trim().toLowerCase(Locale.ROOT);
    SharedPreferences sp = c.getSharedPreferences("juliet", 0);
    String list = sp.getString("contacts", "");
    for (String line : list.split("\n")) {
      int i = line.indexOf('=');
      if (i > 0 && line.substring(0, i).trim().toLowerCase(Locale.ROOT).equals(n)) {
        String d = digits(line.substring(i + 1));
        if (!d.isEmpty()) return d;
      }
    }
    if (has(c, Manifest.permission.READ_CONTACTS)) {
      Cursor cur = null;
      try {
        cur = c.getContentResolver().query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            new String[] {ContactsContract.CommonDataKinds.Phone.NUMBER},
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            new String[] {"%" + name.trim() + "%"}, null);
        if (cur != null && cur.moveToFirst()) return digits(cur.getString(0));
      } catch (Exception e) {
        // ignore
      } finally {
        if (cur != null) cur.close();
      }
    }
    return null;
  }

  /** Number se naam (incoming call announce ke liye). */
  static String nameOf(Context c, String num) {
    if (num == null || num.isEmpty() || !has(c, Manifest.permission.READ_CONTACTS)) return null;
    Cursor cur = null;
    try {
      Uri u = Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num));
      cur = c.getContentResolver().query(u, new String[] {ContactsContract.PhoneLookup.DISPLAY_NAME}, null, null, null);
      if (cur != null && cur.moveToFirst()) return cur.getString(0);
    } catch (Exception e) {
      // ignore
    } finally {
      if (cur != null) cur.close();
    }
    return null;
  }

  static boolean call(Context c, String num) {
    if (num == null || !has(c, Manifest.permission.CALL_PHONE)) return false;
    try {
      TelecomManager tm = (TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
      tm.placeCall(Uri.fromParts("tel", num, null), new Bundle());
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  static boolean sms(Context c, String num, String text) {
    if (num == null || !has(c, Manifest.permission.SEND_SMS)) return false;
    try {
      SmsManager sm;
      if (Build.VERSION.SDK_INT >= 31) sm = c.getSystemService(SmsManager.class);
      else sm = SmsManager.getDefault();
      ArrayList<String> parts = sm.divideMessage(text == null ? "" : text);
      sm.sendMultipartTextMessage(num, null, parts, null, null);
      return true;
    } catch (Exception e) {
      return false;
    }
  }
}
