package com.juliet.ai.announce

import android.app.Notification
import android.app.RemoteInput
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import com.juliet.ai.data.Prefs
import com.juliet.ai.net.GroqClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** User-authorized notification announcements and opt-in private-chat replies.
 * WhatsApp is processed only when Android exposes verifiable one-to-one MessagingStyle metadata.
 * If chat type cannot be verified, automation fails closed and does not call the AI.
 */
class JulietNotificationListener : NotificationListenerService(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val recent = ConcurrentHashMap<String, Long>()
    private val replied = ConcurrentHashMap.newKeySet<String>()
    private val groq = GroqClient()

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) { tts?.language = Locale.getDefault(); ready = true }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName) return
        val n = sbn.notification ?: return
        val extras = n.extras ?: return
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
        val prefs = getSharedPreferences("juliet_announce", MODE_PRIVATE)

        // Announcement and auto-reply are separate opt-ins.
        if (ready && prefs.getBoolean("enabled", false)) announce(sbn, title, text, prefs.getBoolean("read_content", false))

        if (sbn.packageName != "com.whatsapp" && sbn.packageName != "com.whatsapp.w4b") return
        val outgoing = detectOutgoingWhatsAppMessage(n)
        if (outgoing) {
            // A manual owner reply clears the handover flag for this one-to-one conversation.
            val chatKey = "wa_awaiting_${title.hashCode()}"
            getSharedPreferences("juliet_announce", MODE_PRIVATE).edit().remove(chatKey).apply()
            return
        }
        if (!prefs.getBoolean("auto_reply_enabled", false)) return
        val privateChat = verifiedPrivateWhatsAppMessage(n, title, extras) ?: return
        val (sender, incomingText) = privateChat
        val awaitingKey = "wa_awaiting_${title.hashCode()}"
        if (prefs.getBoolean(awaitingKey, false)) return
        if (sender.isBlank() || incomingText.isBlank()) return
        if (incomingText.startsWith("You:", true) || incomingText.startsWith("You ", true)) return
        val messageId = "${sbn.key}|${sbn.postTime}|${sender.hashCode()}|${incomingText.hashCode()}"
        if (!claimMessageId(messageId)) return
        scope.launch { generateAndReply(sbn, title.ifBlank { sender }, sender, incomingText, messageId) }
    }

    @Synchronized private fun claimMessageId(id: String): Boolean {
        if (!replied.add(id)) return false
        val store = getSharedPreferences("juliet_wa_processed", MODE_PRIVATE)
        val saved = store.getStringSet("ids", emptySet())?.toMutableSet() ?: mutableSetOf()
        if (id in saved) return false
        saved.add(id)
        // Store bounded deduplication across process restarts.
        while (saved.size > 500) saved.remove(saved.first())
        store.edit().putStringSet("ids", saved).apply()
        if (replied.size > 500) replied.clear().also { replied.add(id) }
        return true
    }

    private fun detectOutgoingWhatsAppMessage(n: Notification): Boolean {
        return try {
            if (Build.VERSION.SDK_INT < 28) return false
            val style = Notification.MessagingStyle.extractMessagingStyleFromNotification(n) ?: return false
            val last = style.messages.lastOrNull() ?: return false
            val sender = last.person?.name?.toString()?.trim().orEmpty()
            sender.equals("You", true) || sender.equals("You (you)", true) || last.text?.toString()?.trim()?.startsWith("You:", true) == true
        } catch (_: Exception) { false }
    }

    private fun verifiedPrivateWhatsAppMessage(n: Notification, title: String, extras: Bundle): Pair<String, String>? {
        // A normal title alone is not proof of a direct chat. Require MessagingStyle metadata.
        // Before Android 9 the API does not expose a dependable group-conversation flag.
        if (Build.VERSION.SDK_INT < 28) return null
        val style = try { Notification.MessagingStyle.extractMessagingStyleFromNotification(n) } catch (_: Exception) { null } ?: return null
        if (style.isGroupConversation) return null
        if (title.contains("group", true) || title.contains("channel", true) || title.contains("community", true)) return null
        if (Build.VERSION.SDK_INT >= 24 && n.category != Notification.CATEGORY_MESSAGE) return null
        val messages = style.messages
        if (messages.isEmpty()) return null
        val last = messages.last()
        val sender = last.person?.name?.toString()?.trim().orEmpty()
        val content = last.text?.toString()?.trim().orEmpty()
        // No sender identity or message text means chat type/event cannot be trusted.
        if (sender.isBlank() || content.isBlank()) return null
        // Notifications for our own outgoing message may appear as the latest MessagingStyle entry.
        if (sender.equals("You", true) || sender.equals("You (you)", true)) return null
        // Reject obvious channel/broadcast metadata where Android exposes it.
        val conversationTitle = style.conversationTitle?.toString().orEmpty().trim()
        // Direct chats normally have no conversation title. A titled conversation is ambiguous
        // (group, community, or channel), so fail closed rather than send its text to the AI.
        if (conversationTitle.isNotBlank()) return null
        return sender to content
    }

    private suspend fun generateAndReply(sbn: StatusBarNotification, chatTitle: String, sender: String, incoming: String, messageId: String) {
        try {
            val action = sbn.notification.actions?.firstOrNull { a ->
                a.remoteInputs?.isNotEmpty() == true && (a.title?.toString()?.contains("reply", true) == true || a.remoteInputs.any { it.resultKey.isNotBlank() })
            } ?: return
            val remoteInputs = action.remoteInputs ?: return
            val p = Prefs(applicationContext)
            val keys = p.get("k_groq").ifBlank { com.juliet.ai.BuildConfig.DEFAULT_GROQ_KEYS }
                .split(",").map { it.trim() }.filter { it.isNotEmpty() }
            if (keys.isEmpty()) return
            val owner = p.get("name", "Ahsan").ifBlank { "Ahsan" }
            val knowledge = p.get("custom_knowledge").take(6000)
            val historyKey = "wa_ctx_${chatTitle.hashCode()}"
            val oldContext = p.get(historyKey).takeLast(3000)
            val normalized = incoming.trim()
            val system = "You are Juliet, the WhatsApp assistant for $owner. Reply naturally and briefly in the sender's language (Urdu, Roman Urdu, English, or Arabic). Answer the actual message; don't repeat greetings in ongoing chats. Recognize Assalamualaikum, Aslam o Alaikum, AOA, and Salam. For a greeting-only message, respond: وعلیکم السلام ورحمة الله وبركاته. If greeting plus a question, greet briefly and answer the question. Owner work hours are 9:30 AM to 5:00 PM; after 5 PM the owner is generally not at his job, but this is context, never a canned response rule. Custom owner knowledge: $knowledge. Never invent facts. If the message requires $owner's personal decision or you cannot confidently answer from context, reply exactly: Please wait karein, Ahsan sir khud aapko jawab dein ge. Do not claim the owner has been notified. Avoid sensitive/private disclosure. Conversation context: $oldContext"
            val answer = groq.chat(keys, system, listOf(GroqClient.Msg("user", "Incoming private message from $sender: $incoming"))).getOrNull()?.trim().orEmpty()
            if (answer.isBlank()) return
            // Recheck current notification and duplicate state immediately before posting.
            val current = activeNotifications?.firstOrNull { it.key == sbn.key } ?: return
            val currentPrivate = verifiedPrivateWhatsAppMessage(current.notification, current.notification.extras?.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty(), current.notification.extras ?: Bundle()) ?: return
            if (currentPrivate.second != incoming) return
            val fillIn = Intent()
            val results = Bundle()
            remoteInputs.forEach { results.putCharSequence(it.resultKey, answer) }
            RemoteInput.addResultsToIntent(remoteInputs, fillIn, results)
            action.actionIntent.send(this, 0, fillIn)
            p.put(historyKey, (oldContext + "\nThem: " + incoming + "\nJuliet: " + answer).takeLast(3000))
            if (answer.contains("Ahsan sir khud aapko jawab dein ge", true) || answer.contains("Ahsan will personally respond", true)) {
                getSharedPreferences("juliet_announce", MODE_PRIVATE).edit().putBoolean("wa_awaiting_${chatTitle.hashCode()}", true).apply()
            }
        } catch (_: Exception) {
            // Fail closed: no fallback UI tap or guessed message send.
        }
    }

    private fun announce(sbn: StatusBarNotification, title: String, text: String, readContent: Boolean) {
        val now = System.currentTimeMillis()
        val key = sbn.packageName + ":" + sbn.key
        val prev = recent.put(key, now)
        recent.entries.removeIf { now - it.value > 120_000 }
        if (prev != null && now - prev < 30_000) return
        val appName = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(sbn.packageName, 0)).toString() } catch (_: Exception) { sbn.packageName }
        val isWhatsApp = sbn.packageName == "com.whatsapp" || sbn.packageName == "com.whatsapp.w4b"
        val groupLike = isWhatsApp && (title.contains("group", true) || title.contains("channel", true) || title.contains("community", true))
        val spoken = when {
            groupLike -> "New WhatsApp group or channel notification."
            readContent && title.isNotBlank() && text.isNotBlank() -> "$appName notification from $title. $text"
            title.isNotBlank() -> "$appName notification from $title."
            else -> "New notification from $appName."
        }.take(350)
        tts?.speak(spoken, TextToSpeech.QUEUE_ADD, null, "juliet-notification-${sbn.id}-${now}")
    }

    override fun onDestroy() {
        ready = false
        scope.cancel()
        tts?.stop(); tts?.shutdown(); tts = null
        super.onDestroy()
    }
}
