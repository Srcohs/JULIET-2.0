# JULIET AI — Android Source Project

**Branding:** JULIET  
**Owner display name:** Ahsan Raza  
**Platform:** Android / Kotlin / Jetpack Compose

## Project contents
- Android app source and Compose UI
- Chat, saved chat history, local preferences and memory/knowledge screens
- Gemini Live voice integration (requires a valid API key and supported model access)
- Groq text chat integration (requires a valid API key)
- Phone intents for supported actions
- Optional notification announcements and opt-in notification-based WhatsApp reply experiments
- Optional MediaProjection screen capture, subject to Android system consent
- Loudspeaker preference for the in-app voice session
- GitHub Actions workflow to build a debug APK and upload build logs

## Build APK with GitHub Actions
1. Extract this ZIP on your computer.
2. Upload **all extracted files and folders** to the root of your GitHub repository. Do not upload only this ZIP. Make sure `.github/workflows/android.yml` is included.
3. Use the repository's `main` or `master` branch.
4. Open **Actions** and run **JULIET AI Android APK Build**.
5. When the run succeeds, download `JULIET-AI-Debug-APK` from the run's Artifacts section.
6. If it fails, download `JULIET-AI-Build-Log` and share `build.log` so the exact compiler/dependency error can be corrected.

## API keys
Open the app's connection/settings screen and enter your own API keys. Do not commit API keys to GitHub or place them in source files. This app does not include working API credentials.

## Important limitations
This is an Android source project, not a prebuilt or verified APK. The workflow and project configuration are prepared for a cloud build, but this environment does not have the Android SDK/Gradle build environment required to confirm compilation or device behavior. Therefore, I cannot honestly guarantee that every source-level compiler error is already resolved until the cloud build completes successfully.

Android restricts what third-party apps can do. WhatsApp auto-replies depend on notification layout and exposed reply actions and are not an official WhatsApp API integration. Screen capture requires Android's system permission dialog and does not grant unrestricted remote control. Cellular-call audio routing is controlled by Android's dialer; the speaker preference applies to Juliet's in-app voice session, not a separate phone call. Gemini/Groq functionality depends on current provider APIs, model availability, network access, and valid user-owned keys.

## Build APK on GitHub Actions

1. Upload/commit the complete project to your GitHub repository, keeping the `.github/workflows/android.yml` file.
2. Open the repository's **Actions** tab and run **JULIET AI Android APK Build** (or push to `main`/`master`).
3. When the run succeeds, open it and download the `JULIET-AI-Debug-APK` artifact.
4. If the build fails, inspect the failed Gradle step or download `JULIET-AI-Build-Log` for compiler/dependency diagnostics.

The workflow uses Java 17, Gradle 8.7, Android SDK 34, and Android Build Tools 34.0.0 to match this project's Gradle configuration. The archive contains source code, not a prebuilt APK.

