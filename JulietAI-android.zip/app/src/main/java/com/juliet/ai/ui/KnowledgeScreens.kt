package com.juliet.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.juliet.ai.ann.Announcer
import com.juliet.ai.data.KEntry
import com.juliet.ai.vm.JulietViewModel

@Composable
private fun Field(value: String, onValue: (String) -> Unit, hint: String, single: Boolean = true) {
    val p = LocalPal.current
    OutlinedTextField(
        value, onValue, Modifier.fillMaxWidth().padding(bottom = 10.dp), singleLine = single, minLines = if (single) 1 else 3,
        placeholder = { Text(hint, color = p.mu) }, shape = RoundedCornerShape(22.dp),
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = J.Red, unfocusedBorderColor = p.border, cursorColor = J.Crim, focusedTextColor = p.text, unfocusedTextColor = p.text)
    )
}

private fun openListenerSettings(ctx: android.content.Context) {
    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

@Composable
fun KnowledgeScreen(vm: JulietViewModel) = Page("Memory & Auto-Reply", { vm.back() }) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var test by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf<KEntry?>(null) }
    var editText by remember { mutableStateOf("") }
    var consent by remember { mutableStateOf(false) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.permTick++ }
    val tick = vm.permTick
    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }

    Sub("Juliet answers private WhatsApp chats for you using what you save here. Groups and channels are always ignored.")
    Group {
        ToggleItem("💬", "WhatsApp Auto-Reply", if (vm.s("wa_auto") == "1") "ON - replying to private chats" else "OFF", vm.s("wa_auto") == "1") {
            if (it) consent = true else vm.setAutoReply(false)
        }
        Item("🔔", "Notification access", if (listenerOn) "Allowed" else "Needed so Juliet can see WhatsApp messages. Tap to allow.") { openListenerSettings(ctx) }
    }
    Sec("ADD INFORMATION")
    Field(text, { text = it }, "e.g. My work timing is 9:30 AM to 5:00 PM", single = false)
    GradientButton("Save information", Modifier.fillMaxWidth()) { if (vm.addKnowledge(text)) text = "" }
    if (vm.kStatus.isNotEmpty()) Text(vm.kStatus, color = if (vm.kStatus.contains("✔")) J.Ok else J.Red, fontSize = 15.sp, modifier = Modifier.padding(top = 8.dp))
    Spacer(Modifier.height(16.dp))
    Sec("SAVED INFORMATION")
    Field(q, { q = it }, "Search saved information")
    vm.kEntries.filter { it.text.contains(q, true) }.forEach { e ->
        val sh = RoundedCornerShape(20.dp)
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).clip(sh).background(p.card).border(1.dp, p.border, sh).padding(14.dp)) {
            Text(e.text, color = if (e.enabled) p.text else p.mu, fontSize = 16.sp, lineHeight = 22.sp)
            Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                Switch(e.enabled, { vm.toggleKnowledge(e.id, it) }, colors = SwitchDefaults.colors(checkedTrackColor = J.Red, checkedThumbColor = Color.White, uncheckedBorderColor = Color.Transparent))
                Text("Edit", color = J.Crim, fontSize = 16.sp, modifier = Modifier.clickable { editing = e; editText = e.text })
                Text("Delete", color = J.Red, fontSize = 16.sp, modifier = Modifier.clickable { vm.deleteKnowledge(e.id) })
            }
        }
    }
    Spacer(Modifier.height(10.dp))
    Sec("TEST REPLY")
    Field(test, { test = it }, "Type a message as if a contact sent it")
    GradientButton("Test Reply", Modifier.fillMaxWidth()) { vm.testReply(test) }
    if (vm.testResult.isNotEmpty()) Text(vm.testResult, color = p.text, fontSize = 16.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 10.dp))

    if (consent) AlertDialog(
        onDismissRequest = { consent = false }, title = { Text("Turn on auto-reply?") },
        text = { Text("Juliet will read private WhatsApp chat notifications and send AI-written replies for you. The message text is sent to Groq to write the reply. Group and channel messages are ignored. You can turn this off any time.") },
        confirmButton = { TextButton(onClick = { consent = false; vm.setAutoReply(true) }) { Text("I agree", color = J.Red) } },
        dismissButton = { TextButton(onClick = { consent = false }) { Text("Cancel") } }
    )
    editing?.let { e ->
        AlertDialog(
            onDismissRequest = { editing = null }, title = { Text("Edit information") },
            text = { Field(editText, { editText = it }, "Information", single = false) },
            confirmButton = { TextButton(onClick = { vm.updateKnowledge(e.id, editText); editing = null }) { Text("Save", color = J.Red) } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel") } }
        )
    }
}

private val APPS = listOf("📧" to ("Gmail" to "com.google.android.gm"), "📅" to ("Calendar" to "com.google.android.calendar"),
    "✈️" to ("Telegram" to "org.telegram.messenger"), "📷" to ("Instagram" to "com.instagram.android"), "📘" to ("Facebook" to "com.facebook.katana"))

@Composable
fun AnnounceScreen(vm: JulietViewModel, askPerm: (String, (Boolean) -> Unit) -> Unit) = Page("Voice announcements", { vm.back() }) {
    val p = LocalPal.current
    val ctx = LocalContext.current
    var excl by remember { mutableStateOf(vm.s("ann_excl")) }
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.permTick++ }
    val tick = vm.permTick
    val listenerOn = remember(tick) { NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName) }
    fun granted(perm: String) = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
    val callsReady = tick >= 0 && granted(Manifest.permission.READ_PHONE_STATE) && granted(Manifest.permission.READ_CALL_LOG) && granted(Manifest.permission.READ_CONTACTS)
    fun flag(k: String) = vm.s(k) == "1"
    val vol = (vm.s("ann_vol").toFloatOrNull() ?: 100f) / 100f

    Sub("Juliet speaks the caller or sender name. Nothing is spoken during a call, a Juliet voice chat, silent mode or Do Not Disturb.")
    Group {
        ToggleItem("📣", "Voice Announcements", if (flag("ann_on")) "ON" else "OFF", flag("ann_on")) { vm.set("ann_on", if (it) "1" else "0") }
        ToggleItem("📞", "Announce Incoming Calls", "Speaks the saved contact name", flag("ann_calls")) { vm.set("ann_calls", if (it) "1" else "0") }
        ToggleItem("💬", "Announce WhatsApp Messages", "Sender name only", flag("ann_wa")) { vm.set("ann_wa", if (it) "1" else "0") }
        ToggleItem("✉", "Announce SMS Messages", "Sender name only", flag("ann_sms")) { vm.set("ann_sms", if (it) "1" else "0") }
        ToggleItem("🔔", "Announce App Notifications", "Only the apps you select below", flag("ann_apps")) { vm.set("ann_apps", if (it) "1" else "0") }
        ToggleItem("📖", "Read Message Content", "Only works when Privacy Mode is off", flag("ann_content")) { vm.set("ann_content", if (it) "1" else "0") }
        ToggleItem("🛡", "Privacy Mode", "Never reads message text aloud", flag("ann_privacy")) { vm.set("ann_privacy", if (it) "1" else "0") }
        ToggleItem("🔁", "Repeat Announcement", "Says it once more after 15 seconds", flag("ann_repeat")) { vm.set("ann_repeat", if (it) "1" else "0") }
        Item("🔊", "Announcement Volume", vm.s("ann_vol") + "%") { vm.cycle("ann_vol", listOf("100", "80", "60", "40")) }
    }
    Sec("SELECT APPS")
    Group {
        val sel = vm.s("ann_pkgs").split(",").filter { it.isNotBlank() }.toSet()
        APPS.forEach { (icon, a) ->
            ToggleItem(icon, a.first, "", a.second in sel) { on -> vm.set("ann_pkgs", (if (on) sel + a.second else sel - a.second).joinToString(",")) }
        }
    }
    Sec("EXCLUDED CONTACTS")
    Field(excl, { excl = it }, "Names separated by commas")
    GradientButton("Save excluded contacts", Modifier.fillMaxWidth()) { vm.set("ann_excl", excl); vm.toast = "Saved" }
    Spacer(Modifier.height(16.dp))
    Group {
        Item("▶", "Test Voice Announcement", "Plays a sample now") {
            val why = Announcer.speak(ctx, "This is a test announcement from Juliet.", vol, force = true)
            if (why != null) vm.toast = "Not spoken: $why"
        }
        Item("⏹", "Stop Announcement", "Stops what is being spoken") { Announcer.stop() }
    }
    Sec("PERMISSIONS")
    Group {
        Item("🔔", "Notification access", if (listenerOn) "Allowed" else "Needed for message and app announcements. Tap to allow.") { openListenerSettings(ctx) }
        Item("📞", "Call announcements", if (callsReady) "Allowed" else "Needs Phone, Call log and Contacts permission. Tap to allow.") {
            askPerm(Manifest.permission.READ_PHONE_STATE) {
                askPerm(Manifest.permission.READ_CALL_LOG) { askPerm(Manifest.permission.READ_CONTACTS) { vm.permTick++ } }
            }
        }
    }
    Text("Without Call log permission Android does not tell Juliet who is calling, so it can only say \"Incoming call\".", color = p.mu, fontSize = 14.sp, lineHeight = 20.sp)
}
