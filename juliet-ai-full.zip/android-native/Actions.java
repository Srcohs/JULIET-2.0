package com.ahsanraza.juliet;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.hardware.camera2.CameraManager;
import android.media.AudioManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.provider.AlarmClock;
import java.util.List;
import java.util.Locale;
import org.json.JSONObject;

/** Awaaz ke saare phone kaam ek jagah: call, SMS, apps, aur Accessibility se phone control. */
public class Actions {
  static final String NEED_AX = "Pehle Settings me Accessibility allow karo, phir ye kaam hoga.";
  static final String NEED_NL = "Pehle Settings me Notification access allow karo.";

  static boolean view(Context c, String uri) {
    try {
      Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      c.startActivity(i);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  static boolean openApp(Context c, String name) {
    if (name == null || name.trim().isEmpty()) return false;
    try {
      PackageManager pm = c.getPackageManager();
      Intent main = new Intent(Intent.ACTION_MAIN);
      main.addCategory(Intent.CATEGORY_LAUNCHER);
      List<ResolveInfo> l = pm.queryIntentActivities(main, 0);
      String n = name.toLowerCase(Locale.ROOT).trim();
      String pkg = null;
      for (ResolveInfo ri : l) {
        String lab = ri.loadLabel(pm).toString().toLowerCase(Locale.ROOT);
        if (lab.equals(n)) {
          pkg = ri.activityInfo.packageName;
          break;
        }
        if (pkg == null && (lab.contains(n) || n.contains(lab))) pkg = ri.activityInfo.packageName;
      }
      if (pkg == null) return false;
      Intent i = pm.getLaunchIntentForPackage(pkg);
      if (i == null) return false;
      i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
      c.startActivity(i);
      return true;
    } catch (Exception e) {
      return false;
    }
  }

  static String global(int action) {
    JulietAccessibility s = JulietAccessibility.INSTANCE;
    if (s == null) return NEED_AX;
    return s.performGlobalAction(action) ? null : "Ye kaam nahi ho saka.";
  }

  static String run(Context c, JSONObject a) {
    String t = a.optString("type").toLowerCase(Locale.ROOT);
    String name = a.optString("name");
    String text = a.optString("text");
    try {
      if (t.equals("call")) {
        String n = Tools.number(c, name);
        if (n == null) return name + " ka number nahi mila.";
        if (Tools.call(c, n)) return null;
        return view(c, "tel:" + n) ? null : "Call nahi lag saka. Phone permission allow karo.";
      }
      if (t.equals("sms")) {
        String n = Tools.number(c, name);
        if (n == null) return name + " ka number nahi mila.";
        return Tools.sms(c, n, text) ? "SMS bhej diya." : "SMS nahi ja saka. SMS permission allow karo.";
      }
      if (t.equals("whatsapp")) {
        String n = Tools.number(c, name);
        if (n == null) return name + " ka number nahi mila.";
        view(c, "https://wa.me/" + n.replace("+", "") + "?text=" + Uri.encode(text));
        return null;
      }
      if (t.equals("open")) {
        String app = a.optString("app");
        return openApp(c, app) ? null : app + " phone me nahi mila.";
      }
      if (t.equals("url")) {
        String u = a.optString("url");
        if (u.startsWith("http")) view(c, u);
        return null;
      }
      if (t.equals("search")) {
        view(c, "https://www.google.com/search?q=" + Uri.encode(a.optString("q")));
        return null;
      }
      if (t.equals("map")) {
        view(c, "https://www.google.com/maps/search/" + Uri.encode(a.optString("q")));
        return null;
      }
      if (t.equals("back")) return global(AccessibilityService.GLOBAL_ACTION_BACK);
      if (t.equals("home")) return global(AccessibilityService.GLOBAL_ACTION_HOME);
      if (t.equals("recents")) return global(AccessibilityService.GLOBAL_ACTION_RECENTS);
      if (t.equals("notifications")) return global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS);
      if (t.equals("quicksettings")) return global(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS);
      if (t.equals("lock")) {
        if (Build.VERSION.SDK_INT < 28) return "Is Android version par lock nahi ho sakta.";
        return global(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN);
      }
      if (t.equals("screenshot")) {
        if (Build.VERSION.SDK_INT < 28) return "Is Android version par screenshot nahi ho sakta.";
        return global(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT);
      }
      if (t.equals("scroll")) {
        JulietAccessibility s = JulietAccessibility.INSTANCE;
        if (s == null) return NEED_AX;
        return s.scroll(!"up".equalsIgnoreCase(a.optString("dir"))) ? null : "Scroll nahi ho saka.";
      }
      if (t.equals("click")) {
        JulietAccessibility s = JulietAccessibility.INSTANCE;
        if (s == null) return NEED_AX;
        return s.clickText(text) ? null : text + " screen par nahi mila.";
      }
      if (t.equals("type")) {
        JulietAccessibility s = JulietAccessibility.INSTANCE;
        if (s == null) return NEED_AX;
        return s.typeText(text) ? null : "Koi text box select nahi hai.";
      }
      if (t.equals("read_screen")) {
        JulietAccessibility s = JulietAccessibility.INSTANCE;
        if (s == null) return NEED_AX;
        String r = s.readScreen();
        return r.isEmpty() ? "Screen par padhne layak kuch nahi mila." : "Screen par: " + r;
      }
      if (t.equals("volume")) {
        AudioManager am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
        String d = a.optString("dir").toLowerCase(Locale.ROOT);
        if (d.equals("down")) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI);
        else if (d.equals("mute")) am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI);
        else if (d.equals("max")) am.setStreamVolume(AudioManager.STREAM_MUSIC, am.getStreamMaxVolume(AudioManager.STREAM_MUSIC), AudioManager.FLAG_SHOW_UI);
        else am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI);
        return null;
      }
      if (t.equals("flashlight")) {
        CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
        boolean on = !"false".equalsIgnoreCase(a.optString("on", "true"));
        cm.setTorchMode(cm.getCameraIdList()[0], on);
        return on ? "Torch on." : "Torch off.";
      }
      if (t.equals("alarm")) {
        Intent i = new Intent(AlarmClock.ACTION_SET_ALARM);
        i.putExtra(AlarmClock.EXTRA_HOUR, a.optInt("hour", 7));
        i.putExtra(AlarmClock.EXTRA_MINUTES, a.optInt("minute", 0));
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
        return "Alarm laga diya.";
      }
      if (t.equals("timer")) {
        Intent i = new Intent(AlarmClock.ACTION_SET_TIMER);
        i.putExtra(AlarmClock.EXTRA_LENGTH, a.optInt("seconds", 60));
        i.putExtra(AlarmClock.EXTRA_SKIP_UI, true);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
        return "Timer laga diya.";
      }
      if (t.equals("battery")) {
        BatteryManager bm = (BatteryManager) c.getSystemService(Context.BATTERY_SERVICE);
        return "Battery " + bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) + " percent hai.";
      }
      if (t.equals("read_notifications")) {
        String r = JulietNotifications.recent(c);
        return r == null ? NEED_NL : r;
      }
      if (t.equals("clear_notifications")) {
        return JulietNotifications.clearAll() ? "Notifications saaf kar di." : NEED_NL;
      }
    } catch (Exception e) {
      return "Kaam nahi ho saka: " + e.getMessage();
    }
    return null;
  }
}
