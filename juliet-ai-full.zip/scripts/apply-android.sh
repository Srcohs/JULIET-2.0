#!/usr/bin/env bash
# Capacitor ne android/ folder banane ke baad: native code, permissions, service aur Juliet ke icons lagata hai.
set -euo pipefail
python3 scripts/patch_android.py
M=android/app/src/main
rm -rf "$M"/res/mipmap-anydpi-v26 "$M"/res/mipmap-*/ic_launcher*.png
for d in mdpi hdpi xhdpi xxhdpi xxxhdpi; do
  mkdir -p "$M/res/mipmap-$d"
  cp icons/mipmap-$d/ic_launcher.png icons/mipmap-$d/ic_launcher_round.png "$M/res/mipmap-$d/"
done
echo "Android setup poora."
