"""Capacitor ke generate kiye android/ project me Juliet ka native code, permissions aur service lagata hai."""
import glob
import os
import shutil
import sys

root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
manifest = os.path.join(root, "android/app/src/main/AndroidManifest.xml")
pkg_dir = os.path.join(root, "android/app/src/main/java/com/ahsanraza/juliet")
os.makedirs(pkg_dir, exist_ok=True)
for f in glob.glob(os.path.join(root, "android-native", "*.java")):
    shutil.copy(f, pkg_dir)
    print("copied", os.path.basename(f))

s = open(manifest, encoding="utf-8").read()
perms = [
    "ACCESS_COARSE_LOCATION", "ACCESS_FINE_LOCATION", "RECORD_AUDIO", "MODIFY_AUDIO_SETTINGS",
    "CALL_PHONE", "SEND_SMS", "READ_CONTACTS", "READ_PHONE_STATE", "READ_CALL_LOG", "ANSWER_PHONE_CALLS",
    "FOREGROUND_SERVICE", "FOREGROUND_SERVICE_MICROPHONE", "POST_NOTIFICATIONS",
    "REQUEST_IGNORE_BATTERY_OPTIMIZATIONS", "VIBRATE",
]
full_perms = ["com.android.alarm.permission.SET_ALARM"]
add = ""
for p in perms:
    line = '<uses-permission android:name="android.permission.%s" />' % p
    if line not in s and ('android.permission.%s"' % p) not in s:
        add += line + "\n    "
queries = (
    "<queries>\n"
    '        <intent><action android:name="android.intent.action.MAIN" /><category android:name="android.intent.category.LAUNCHER" /></intent>\n'
    '        <intent><action android:name="android.intent.action.TTS_SERVICE" /></intent>\n'
    '        <intent><action android:name="android.speech.RecognitionService" /></intent>\n'
    "    </queries>\n    "
)
for fp in full_perms:
    if fp not in s:
        add += '<uses-permission android:name="%s" />\n    ' % fp
if "<queries>" not in s:
    add += queries
elif "category.LAUNCHER" not in s.split("<queries>")[1].split("</queries>")[0]:
    s = s.replace("<queries>", "<queries>\n        <intent><action android:name=\"android.intent.action.MAIN\" /><category android:name=\"android.intent.category.LAUNCHER\" /></intent>", 1)
if "<application" not in s or "</application>" not in s:
    sys.exit("AndroidManifest.xml me application tag nahi mila")
s = s.replace("<application", add + "<application", 1)
svc = '<service android:name=".JulietService" android:exported="false" android:foregroundServiceType="microphone" />\n    '
if "JulietService" not in s:
    s = s.replace("</application>", svc + "</application>", 1)
ax = (
    '<service android:name=".JulietAccessibility" android:exported="true" android:label="Juliet AI" '
    'android:permission="android.permission.BIND_ACCESSIBILITY_SERVICE">'
    '<intent-filter><action android:name="android.accessibilityservice.AccessibilityService" /></intent-filter>'
    '<meta-data android:name="android.accessibilityservice" android:resource="@xml/juliet_accessibility" /></service>\n    '
)
nl = (
    '<service android:name=".JulietNotifications" android:exported="true" android:label="Juliet AI" '
    'android:permission="android.permission.BIND_NOTIFICATION_LISTENER_SERVICE">'
    '<intent-filter><action android:name="android.service.notification.NotificationListenerService" /></intent-filter></service>\n    '
)
if "JulietAccessibility" not in s:
    s = s.replace("</application>", ax + "</application>", 1)
if "JulietNotifications" not in s:
    s = s.replace("</application>", nl + "</application>", 1)
open(manifest, "w", encoding="utf-8").write(s)
res_src = os.path.join(root, "android-native", "res")
res_dst = os.path.join(root, "android/app/src/main/res")
shutil.copytree(res_src, res_dst, dirs_exist_ok=True)
print("res copied")
print("manifest patched")
